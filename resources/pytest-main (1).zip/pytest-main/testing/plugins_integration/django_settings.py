SECRET_KEY = "mysecret"
